<?php
require_once 'config.php';
require_once 'User.php';

$db = (new Database())->getConnection();
$user = new User($db);

$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $message = $user->login($username, $password);
}
include 'header.php';
?>
<div class="card p-4 shadow">   
    <h2 class="text-center">Login</h2>
    <form method="POST">
        <?php if ($message): ?>
            <div class="alert alert-info"><?= $message ?></div>
        <?php endif; ?>
        <div class="mb-3">
            <label for="username" class="form-label">Username</label>
            <input type="text" name="username" id="username" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Password</label>
            <input type="password" name="password" id="password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">Login</button>
    </form>
</div>
<?php include 'footer.php'; ?>
