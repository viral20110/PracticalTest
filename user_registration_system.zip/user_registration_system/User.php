<?php
require_once 'config.php';

class User {
    private $conn;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function register($firstName, $lastName, $email, $username, $password, $file) {
        // Check if email is unique
        $checkEmail = $this->conn->prepare("SELECT id FROM users WHERE email = :email");
        $checkEmail->bindParam(":email", $email);
        $checkEmail->execute();
        if ($checkEmail->rowCount() > 0) {
            return "Email is already taken.";
        }

        // Hash password using MD4
        $hashedPassword = hash("md4", $password);

        // Save file
        $targetDir = "uploads/";
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0777, true);
        }
        $filePath = $targetDir . basename($file["name"]);
        if (!move_uploaded_file($file["tmp_name"], $filePath)) {
            return "Failed to upload file.";
        }

        // Insert user data
        $query = "INSERT INTO users (first_name, last_name, email, username, password, file_path) 
                  VALUES (:first_name, :last_name, :email, :username, :password, :file_path)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":first_name", $firstName);
        $stmt->bindParam(":last_name", $lastName);
        $stmt->bindParam(":email", $email);
        $stmt->bindParam(":username", $username);
        $stmt->bindParam(":password", $hashedPassword);
        $stmt->bindParam(":file_path", $filePath);

        return $stmt->execute() ? "Registration successful!" : "Failed to register.";
    }

    public function login($username, $password) {
        $query = "SELECT * FROM users WHERE username = :username";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":username", $username);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && $user['password'] === hash("md4", $password)) {
            return "Login successful!";
        }
        return "Invalid username or password.";
    }
}
?>
