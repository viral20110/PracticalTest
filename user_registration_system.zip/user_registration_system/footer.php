</div>
    <footer class="bg-white text-center text-muted py-3 mt-5 shadow-sm">
        <div class="container">
            &copy; <?= date('Y'); ?> User System. All rights reserved.
        </div>
    </footer>
</body>
</html>